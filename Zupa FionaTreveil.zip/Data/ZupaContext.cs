﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Zupa.Models;

namespace Zupa.Models
{
    public class ZupaContext : DbContext
    {
        public ZupaContext (DbContextOptions<ZupaContext> options)
            : base(options)
        {
        }

        public DbSet<Zupa.Models.Meeting> Meeting { get; set; }

        public DbSet<Zupa.Models.Seat> Seat { get; set; }
        
                        protected override void OnModelCreating(ModelBuilder modelBuilder)
                        {
                            modelBuilder.Entity<Meeting>().HasData(new Meeting { Id = 1, Date = "2018-11-01" });
                            modelBuilder.Entity<Meeting>().HasData(new Meeting { Id = 2, Date = "2018-11-16" });
                            modelBuilder.Entity<Seat>().HasData(new Seat { Id = 1, Row = 1, Col = 1, Email = "111@gmail", MeetingId = 1 });
                            modelBuilder.Entity<Seat>().HasData(new Seat { Id = 2, Row = 2, Col = 3, Email = "231@gmail", MeetingId = 1 });
                            modelBuilder.Entity<Seat>().HasData(new Seat { Id = 3, Row = 1, Col = 1, Email = "112@gmail", MeetingId = 2 });
                            modelBuilder.Entity<Seat>().HasData(new Seat { Id = 4, Row = 3, Col = 4, Email = "341@gmail", MeetingId = 2 });
                        } 
          
    }
}
